﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TPLP2.Model
{
    #region ClassInterface
    public interface IGuardarFornecedores
    {
        bool AddFornecedor(IFornecedorModel i);
        bool SaveFornecedores(string fileName);
        bool LoadFornecedores(string fileName);
        bool RemoveFornecedor(int id);
        List<IFornecedorModel> GiveList();
        IFornecedorModel FindFornecedor(int id);
        
    }
    #endregion

    #region ClassModel
    [Serializable]
    public class GuardarFornecedores: IGuardarFornecedores
    {
        #region Atributes
        public List<IFornecedorModel> listForn;
        #endregion

        #region Methods

        #region Constructor
        public GuardarFornecedores()
        {
            listForn = new List<IFornecedorModel>();
        }
        #endregion

        #region Functions
        // Adicionar fornecedores a uma lista
        public bool AddFornecedor(IFornecedorModel i)
        {
            if  (listForn != null)
            {
                if (listForn.Contains(i))
                {
                    return false;
                }
                else
                {
                    listForn.Add(i);
                    return true;
                }
            }
            else
            {
                listForn = new List<IFornecedorModel>();
                listForn.Add(i);
                return true;
            }
        }
        // Guardar lista de Fornecedores num ficheiro
        public bool SaveFornecedores(string fileName)
        {
            if(listForn != null)
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, listForn);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
            
            
        }
        // Carregar lista de fornecedores de um ficheiro
        public bool LoadFornecedores(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    listForn = (List<IFornecedorModel>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
        }
        public IFornecedorModel FindFornecedor(int id)
        {
            return listForn.Find(x => (x.IdFornecedor == id) && (x.IsAtivo == true));
        }
        public List<IFornecedorModel> GiveList()
        {
            return listForn;
        }

        public bool RemoveFornecedor(int id)
        {
            IFornecedorModel c = FindFornecedor(id);
            if (c != null)
            {
                c.IsAtivo = false;
                return true;
            }
            return false;
        }
        #endregion
        #endregion
    }
#endregion
}
