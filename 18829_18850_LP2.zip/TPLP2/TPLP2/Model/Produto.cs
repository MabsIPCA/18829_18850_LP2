﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TPLP2.Model

{
    /// <summary>
    /// Purpose:
    /// Created by: Miguel & Leonel
    /// Created on: 18 Abril 2020
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    /// 

    public interface IProdutoModel
    {
        int IdProduto { set; get; }
        string Nome { set; get; }
        string Descri { set; get; }
        string Categoria { set; get; }
        int IdFornecedor { set; get; }
        float Preco { set; get; }
        bool IsAtivo { set; get; }
        bool UpdateProduto(string nome, string desc, string cat, int fornId, float preco);

    }
    [Serializable]
    public class Produto:IProdutoModel
    {
        #region Attributes
        public int IdProduto { set; get; }
        public string Nome { set; get; }
        public string Descri { set; get; }
        public string Categoria { set; get; }
        public int IdFornecedor { set; get; }
        public float Preco { set; get; }
        public bool IsAtivo { set; get; }
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Produto(int id,string n,string des,string ca, int f, float p)
        {
            IdProduto = id;
            Nome = n;
            Categoria = ca;
            IdFornecedor = f;
            Preco = p;
            Descri = des;
            IsAtivo = true;

    }

        #endregion

        #region Properties
        #endregion

        #region Functions
        public bool UpdateProduto(string nome, string desc, string cat, int fornId, float preco) {
            Nome = nome;
            Categoria = cat;
            IdFornecedor = fornId;
            Preco = preco;
            Descri = desc;
            return true;
        }
        #endregion

        #region Overrides
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~Produto()
        {
        }
        #endregion

        #endregion
    }
}
