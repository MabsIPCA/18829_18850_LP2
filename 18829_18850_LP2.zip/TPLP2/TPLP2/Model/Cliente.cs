﻿using System;
using System.Collections.Generic;
using System.Text;
using TPLP2.Classes;

namespace TPLP2.Model
{
    /// <summary>
    /// Purpose:
    /// Created by: Miguel & Leonel
    /// Created on: 18 Abril 2020
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    /// 
    #region ClassInterface
    public interface IClienteModel
    {
        string Nome { set; get; }
        int Contacto { set; get; }
        string Morada { set; get; }
        DateTime DataNascimento { set; get; }
        int IdCliente { set; get; }
        int NIF { set; get; }
        string Empresa { set; get; }
        bool IsAtivo { set; get; }
        bool UpdateCliente(string n, int c, string m, DateTime d, int nif, string empresa);

    }
    #endregion

    #region ClassModel
    [Serializable]
    public class Cliente : Pessoa, IClienteModel
    {
        #region Attributes
        public int IdCliente { set; get; }
        public int NIF { set; get; }
        public string Empresa { set; get; }
        public bool IsAtivo { set; get; }
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Cliente( string n, int c, string m, DateTime d, int id,int nif, string empresa) : base(n,c,m,d)
        {
            IdCliente = id;
            DataNascimento = d;
            Empresa = empresa;
            NIF = nif;
            IsAtivo = true;
        }

        #endregion

        #region Properties
        #endregion

        #region Functions
        public bool UpdateCliente(string n, int c, string m, DateTime d, int nif, string empresa)
        {
            Nome = n;
            Contacto = c;
            Morada = m;
            DataNascimento = d;
            Empresa = empresa;
            NIF = nif;
            return true;
        }
        #endregion

        #region Overrides
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~Cliente()
        {
        }
        #endregion

        #endregion
    }
    #endregion
}
