﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TPLP2.Model
{
    #region ClassInterface
    public interface IGuardarTransportadoras
    {
        bool AddTransportadora(ITransportadoraModel i);
        bool SaveTransportadoras(string fileName);
        bool LoadTransportadoras(string fileName);
        bool RemoveTransportadora(int id);
        List<ITransportadoraModel> GiveList();
        ITransportadoraModel FindTransportadora(int id);
    }
    #endregion

    #region ClassModel
    [Serializable]
    public class GuardarTransportadoras: IGuardarTransportadoras
    {
        #region Atributes
        public List<ITransportadoraModel> listTrans;
        #endregion

        #region Methods
        #region Constructor
        public GuardarTransportadoras()
        {
            listTrans = new List<ITransportadoraModel>();
        }
        #endregion

        #region Functions
        public bool AddTransportadora(ITransportadoraModel i)
        {
            if (listTrans != null)
            {
                if (listTrans.Contains(i))
                {
                    return false;
                }
                else
                {
                    listTrans.Add(i);
                    return true;
                }
            }
            else
            {

                listTrans = new List<ITransportadoraModel>();
                listTrans.Add(i);
                return true;
            }
        }
        public bool SaveTransportadoras(string fileName)
        {
            if(listTrans != null)
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, listTrans);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
        }
        public bool LoadTransportadoras(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    listTrans = (List<ITransportadoraModel>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch(IOException e)
                {
                    throw e;
                }
            }
            return false;
        }
        public ITransportadoraModel FindTransportadora(int id)
        {
            return listTrans.Find(x => (x.IdTransportadora == id) && (x.IsAtivo == true));
        }

        public List<ITransportadoraModel> GiveList()
        {
            return listTrans;
        }

        public bool RemoveTransportadora(int id)
        {
            ITransportadoraModel t = FindTransportadora(id);
            if (t != null)
            {
                t.IsAtivo = false;
                return true;
            }
            return false;
        }
        #endregion
        #endregion
    }
    #endregion
}
