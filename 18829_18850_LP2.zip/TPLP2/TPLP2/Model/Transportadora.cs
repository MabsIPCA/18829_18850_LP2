﻿using System;
using System.Collections.Generic;
using System.Text;
using TPLP2.Classes;

namespace TPLP2.Model
{

    /// <summary>
    /// Purpose:
    /// Created by: Miguel & Leonel
    /// Created on: 18 Abril 2020
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    /// 
    public interface ITransportadoraModel
    {
        string Nome { set; get; }
        int Contacto { set; get; }
        string Morada { set; get; }
        int IdTransportadora { set; get; }
        int NVeiculos { set; get; }
        bool IsAtivo { set; get; }
        bool UpdateTransportadora(string nome, int con, string mor, int nv);
    }
    [Serializable]
    public class Transportadora:Empresa, ITransportadoraModel
    {
        #region Attributes
        public int IdTransportadora { set; get; }
        public int NVeiculos { set; get; }
        public bool IsAtivo { set; get; }
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Transportadora(string nome, int con, string mor, int nv, int id) :base(nome,con,mor)
        {
            NVeiculos = nv;
            Nome = nome;
            Contacto = con;
            Morada = mor;
            IdTransportadora = id;
            IsAtivo = true;
        }

        #endregion

        #region Properties
        #endregion

        #region Functions
        public bool UpdateTransportadora(string nome, int con, string mor, int nv)
        {
            NVeiculos = nv;
            Nome = nome;
            Contacto = con;
            Morada = mor;
            return true;
        }
        #endregion

        #region Overrides
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~Transportadora()
        {
        }
        #endregion

        #endregion
    }
}
