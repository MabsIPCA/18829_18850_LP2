﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using TPLP2.Classes;

namespace TPLP2.Model
{


    /// <summary>
    /// Purpose:
    /// Created by: Miguel & Leonel
    /// Created on: 18 Abril 2020
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    /// 
    public interface IFornecedorModel
    {
        string Nome { set; get; }
        int Contacto { set; get; }
        string Morada { set; get; }
        int IdFornecedor { set; get; }
        string Categoria { set; get; }
        bool IsAtivo { set; get; }
        bool UpdateFornecedor(string nome, int con, string mor, string cat);
    }
    [Serializable]
    public class Fornecedor:Empresa,IFornecedorModel
    {
        #region Attributes
        public int IdFornecedor { set; get; }
        public string Categoria { set; get; }
        public bool IsAtivo { set; get; }
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Fornecedor(string nome, int con, string mor, string cat,int id):base(nome,con,mor)
        {
            IdFornecedor = id;
            Categoria = cat;
            IsAtivo = true;
        }

        #endregion

        #region Properties
        #endregion

        #region Functions
        public bool UpdateFornecedor(string nome, int con, string mor, string cat)
        {
            Categoria = cat;
            Nome = nome;
            Contacto = con;
            Morada = mor;
            
            return true;
        }
        #endregion

        #region Overrides
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~Fornecedor()
        {
        }
        #endregion

        #endregion
    }
}
