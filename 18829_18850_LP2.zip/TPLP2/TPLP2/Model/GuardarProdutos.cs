﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TPLP2.Model
{
    #region ClassInterface
    public interface IGuardarProdutos
    {
        bool AddProduto(IProdutoModel i);
        bool SaveProdutos(string fileName);
        bool LoadProdutos(string fileName);
        List<IProdutoModel> GiveList();
        IProdutoModel FindProduto(int id);
        bool RemoveProduto(int id);
    }
    #endregion

    #region ClassModel
    [Serializable]
    public class GuardarProdutos : IGuardarProdutos
    {
        #region Atributes
        public List<IProdutoModel> listProd;
        #endregion

        #region Methods
        #region Constructor
        public GuardarProdutos()
        {
            listProd = new List<IProdutoModel>();
        }
        #endregion

        #region Functions
        // Adicionar produtos a uma lista
        public bool AddProduto(IProdutoModel i)
        {
            if (listProd != null)
            {
                if (listProd.Contains(i))
                {
                    return false;
                }
                else
                {
                    listProd.Add(i);
                    return true;
                }
            }
            else
            {

                listProd = new List<IProdutoModel>();
                listProd.Add(i);
                return true;
            }
        }
        // Guardar lista de Produtos num ficheiro

        public bool SaveProdutos(string fileName)
        {
            if(listProd != null)
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, listProd);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
            
        }
        // Carregar lista de Produtos de um ficheiro
        public bool LoadProdutos(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    listProd = (List<IProdutoModel>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
        }

        public IProdutoModel FindProduto(int id)
        {
            return listProd.Find(x => (x.IdProduto == id) && (x.IsAtivo == true));
        }

        public List<IProdutoModel> GiveList()
        {
            return listProd;
        }

        public bool RemoveProduto(int id)
        {
            IProdutoModel p = FindProduto(id);
            if (p != null)
            {
                p.IsAtivo = false;
                return true;
            }
            return false;
        }
        #endregion
        #endregion
    }
    #endregion
}
