﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TPLP2.Model
{
    #region ClassInterface
    public interface IGuardarClientes
    {
        
        bool AddCliente(IClienteModel i);
        bool SaveClientes(string fileName);
        bool LoadClientes(string fileName);
        bool RemoveCliente(int id);
        List<IClienteModel> GiveList();
        IClienteModel FindCliente(int id);
    }
    #endregion

    #region ClassModel
    [Serializable]
    public class GuardarClientes : IGuardarClientes
    {
        #region Atributes
        public List<IClienteModel> listCliente;
        #endregion

        #region Methods

        #region Constructors
        public GuardarClientes()
        {
            listCliente = new List<IClienteModel>();
        }
        #endregion

        #region Functions
        public bool AddCliente(IClienteModel i)
        {

            if (listCliente != null)
            {
                if (listCliente.Contains(i))
                {
                    return false;
                }
                else
                {
                    listCliente.Add(i);
                    return true;
                }
            }
            else
            {

                listCliente = new List<IClienteModel>();
                listCliente.Add(i);
                return true;
            }
        }

        public bool SaveClientes(string fileName)
        {
            if (listCliente != null)
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, listCliente);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;          

        }

        public bool LoadClientes(string fileName)
        {

            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    listCliente = (List<IClienteModel>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
        }

        public IClienteModel FindCliente(int id)
        {
            return listCliente.Find(x => (x.IdCliente == id) && (x.IsAtivo == true));
        }

        public List<IClienteModel> GiveList()
        {
            return listCliente;
        }


        public bool RemoveCliente(int id)
        {
            IClienteModel c = FindCliente(id);
            if (c != null)
            {
                c.IsAtivo = false;
                return true;
            }
            return false;
        }
        #endregion

        #endregion
    }
    #endregion
}
