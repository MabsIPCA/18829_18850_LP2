﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TPLP2.Model
{
    #region ClasseInterface
    public interface IGuardarEncomendas
    {
        bool AddEncomenda(IEncomendaModel i);
        bool SaveEncomendas(string fileName);
        bool LoadEncomendas(string fileName);
        IEncomendaModel FindEncomenda(int id);
        List<IEncomendaModel> GiveList();
        bool RemoveEncomenda(int id);        
        
    }
    #endregion


    #region ClassModel
    [Serializable]
    public class GuardarEncomendas: IGuardarEncomendas
    {
        #region Atributes
        public List<IEncomendaModel> listEncom;
        #endregion

        #region Methods

        #region Constructor
        public GuardarEncomendas()
        {
            listEncom = new List<IEncomendaModel>();
        }
        #endregion

        #region Functions
        public bool AddEncomenda(IEncomendaModel i)
        {
            if (listEncom != null)
            {
                if (listEncom.Contains(i))
                {
                    return false;
                }
                else 
                {
                    listEncom.Add(i);
                    return true;
                }
                
            }
            else
            {
                listEncom = new List<IEncomendaModel>();
                listEncom.Add(i);
                return true;
            }
        }
        public bool SaveEncomendas(string fileName)
        {
            if(listEncom != null)
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, listEncom);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
            
        }

        public bool LoadEncomendas(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    listEncom = (List<IEncomendaModel>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch(IOException e)
                {
                    throw e;
                }
            }
            return false;
        }
        public IEncomendaModel FindEncomenda(int id)
        {
            return listEncom.Find(x => (x.IdEncomenda == id) && (x.IsAtivo == true));
        }

        public List<IEncomendaModel> GiveList()
        {
            return listEncom;
        }
        
        public bool RemoveEncomenda(int id)
        {
            IEncomendaModel e = FindEncomenda(id);
            if (e != null)
            {
                e.IsAtivo = false;
                return true;
            }
            return false;
        }
        #endregion
        #endregion
    }
    #endregion
}
