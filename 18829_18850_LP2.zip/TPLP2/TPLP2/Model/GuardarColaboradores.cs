﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace TPLP2.Model
{
    #region ClassInterface
    public interface IGuardarColaboradores
    {
        bool AddColaborador(IColaboradorModel i);
        bool SaveColaboradores(string fileName);
        bool LoadColaboradores(string fileName);
        IColaboradorModel FindColaborador(int id);
        List<IColaboradorModel> GiveList();
        bool RemoveColaborador(int id);
    }
    #endregion


    #region ClassModel
    [Serializable]
    public class GuardarColaboradores: IGuardarColaboradores
    {
        #region Atributes
        public List<IColaboradorModel> listColab;
        #endregion

        #region Methods

        #region Constructor
        public GuardarColaboradores()
        {
            listColab = new List<IColaboradorModel>();
        }
        #endregion

        #region Functions
        public bool AddColaborador(IColaboradorModel i)
        {
            if (listColab != null)
            {
                if (listColab.Contains(i))
                {
                    return false;
                }
                else
                {
                    listColab.Add(i);
                    return true;
                }
            }
            else
            {

                listColab = new List<IColaboradorModel>();
                listColab.Add(i);
                return true;
            }
        }

        public bool SaveColaboradores(string fileName)
        {
            if(listColab != null)
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream, listColab);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }
            return false;
            
        }
        public bool LoadColaboradores(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    listColab = (List<IColaboradorModel>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch(IOException e)
                {
                    throw e;
                }
            }
            return false;
        }
        public IColaboradorModel FindColaborador(int id)
        {

            return listColab.Find(x => (x.NColaborador == id) && (x.IsAtivo == true));
        }

        public List<IColaboradorModel> GiveList()
        {
            return listColab;
        }

        public bool RemoveColaborador(int id)
        {
            IColaboradorModel c = FindColaborador(id);
            if (c != null)
            {
                c.IsAtivo = false;
                return true;
            }
            return false;
        }
        #endregion

        #endregion
    }
    #endregion
}
