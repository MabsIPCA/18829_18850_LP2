﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Model;
using TPLP2.View;

namespace TPLP2.Controller
{
    #region ClassInterface
    public interface ITransportadoraController // Interface do Controller de Transportadora
    {
        void setModel(ITransportadoraModel m);
        void setModel(IGuardarTransportadoras m);
        void Menu();
        void updateTransportadora(string nome, int con, string mor, int nv);
        void NewTransportadora(int id, string nome, int con, string mor, int nv);
        bool SearchTransportadora(int id);
        bool RemoveTransportadora(int id);
        void setView(ITransportadoraView v);
        void SaveTransportadoras();
        (string, int, string, int) GiveTransportadora(int id);
        void RequestTransportadora();
        void RequestRemove();
        void RequestUpdate();
        void RequestShowTransportadora();
        void RequestShowAllTransportadoras();
        int RequestMenu();
    }
    #endregion


    #region ClasseController
    class TransportadoraController:ITransportadoraController
    {
        #region Atributes
        //Atributos da Classe
        public ITransportadoraModel trans; // Define o model de Transportadora
        private IGuardarTransportadoras transList; // Define a class da Lista de Transportadora
        private ITransportadoraView transView; // Define a View de Transportadora
        #endregion


        #region Methods

        #region Constructor
        public TransportadoraController()
        {
            transList = new GuardarTransportadoras(); //Define uma nova classe de Guardar Transportadora
            transList.LoadTransportadoras("transportadoras.bin"); // Carrega a lista do ficheiro
            transView = new TransportadoraView(this); // Define a view de Transportadora
        }
        #endregion

        #region Functions

        #region Fluxo de Dados
        
        public void setModel(ITransportadoraModel m) //Define o Model de Transportadora
        {
            trans = m;
        }
        public void updateTransportadora(string nome, int con, string mor, int nv) //Recebe os dados da view para fazer update do alterar uma transportadora
        {
            trans.UpdateTransportadora( nome,  con,  mor,  nv);
        }

        public void setModel(IGuardarTransportadoras m) //Define o model da lista de Tranportadoras
        {
            transList = m;
        }

        public void SaveTransportadoras() //Envia para o model o path para guardar transportadoras em ficheiro
        {
            transList.SaveTransportadoras("transportadoras.bin");
        }


        public void NewTransportadora(int id, string nome, int con, string mor, int nv) //Envia para o model dados para adicionar uma transportadora à lista
        {
            Transportadora transportadoraAdicionar = new Transportadora(nome, con, mor, nv, id);
            if (transList != null)
            {
                //testar de não existe
                transList.AddTransportadora(transportadoraAdicionar);
            }
        }

        public bool SearchTransportadora(int id) //Verifica se uma determinada transportadora existe na lista atraves do id
        {
            ITransportadoraModel t;
            if (transList != null)
            {
                //testar de não existe
                t = transList.FindTransportadora(id);
                if (t != null)
                {
                    setModel(t);
                    return true;
                }
            }
            return false;
        }

        public bool RemoveTransportadora(int id) //Recebe um ID por parte da view para remover uma transportadora da lista
        {
            if (transList.RemoveTransportadora(id))
            {
                return true;
            }
            return false;
        }

        public (string, int, string, int) GiveTransportadora(int id) //Envia para a view os dados de uma transportadora presente na lista
        {
            trans = transList.FindTransportadora(id);

            return (trans.Nome, trans.Contacto, trans.Morada, trans.NVeiculos);
        }
        #endregion

        #region Views
        public void setView(ITransportadoraView v) //Instancia a view de transportadora
        {
            this.transView = v;
        }

        public void RequestTransportadora() //Corre o Método da view que pede para o utilizador adicionar uma trasnportadora 
        {
            if(transView != null)
            {
                transView.ViewAddTransportadora();
            }
        }

        public void RequestRemove() //Corre o Método da view que pede para o utilizador remover uma transportadora
        {
            if(transView != null)
            {
                transView.ViewRemoveTransportadora();
            }
        }

        public void RequestUpdate() //Corre o Método da view que pede para o utilizador alterar uma transportadora
        {
            if(transView != null)
            {
                transView.ViewUpdateTransportadora();
            }
        }
        public void RequestShowTransportadora() //Corre o Método da View que pede um ID ao utilizador para mostrar o cliente e os seus dados
        {
            if(transView != null) 
            {
                if (transList != null)
                {
                    transView.ViewShowTransportadora();
                    Console.ReadKey();
                }
                else
                {
                    transView.TransNoList();
                }
            }
           
            
        }

        public void RequestShowAllTransportadoras() //Chama o Método da View que mostra todos os clientes presentes e os seus dados
        {
            if(transView != null)
            {
                if (transList != null)
                {
                    foreach (ITransportadoraModel i in transList.GiveList())
                    {
                        if (i.IsAtivo)
                        {
                            transView.ViewShowAllTransportadoras(i.Nome, i.Contacto, i.Morada, i.NVeiculos, i.IdTransportadora);
                        }
                    }
                    Console.ReadKey();
                }
                else
                {
                    transView.TransNoList();
                }
            }
            
            
        }
        #endregion

        #region Menu
        public void Menu() //CHama o Método do Menu
        {
            int op = RequestMenu();
            if (op > 0)
            {
                switch (op)
                {
                    case 1:
                        RequestShowAllTransportadoras();
                        break;
                    case 2:
                        RequestTransportadora();
                        break;
                    case 3:
                        RequestShowTransportadora();
                        break;
                    case 4:
                        RequestUpdate();
                        break;
                    case 5:
                        RequestRemove();
                        break;
                    case 6:
                        break;
                }
            }

        }

        public int RequestMenu() //Pede à view que apresente o menu e receba as escolhas do utilizador
        {
            
            if (transView != null)
            {
                return transView.ViewMenuTransportadora();
            }
            return -1;
        }
        #endregion

        #endregion
        #endregion

    }
    #endregion
}
