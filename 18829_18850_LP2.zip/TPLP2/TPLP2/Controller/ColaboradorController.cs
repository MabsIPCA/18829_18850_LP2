﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Model;
using TPLP2.View;

namespace TPLP2.Controller
{
    #region ClassInterface
    public interface IColaboradorController // Interface de Controller de Colaborador
    {
        void setModel(IColaboradorModel m);
        void setModel(IGuardarColaboradores m);

        void Menu();
        void updateColaborador(string n, int c, string m, DateTime d, string cat);
        void NewColaborador(string n, int c, string m, DateTime d, string cat, int nc, DateTime dc, int dcmeses);
        bool SearchColaborador(int id);
        bool RemoveColaborador(int id);
        void setView(IColaboradorView v);
        void SaveColaboradores();
        (string, int, string, DateTime, string, DateTime, int) GiveColaborador(int id);
        void RequestColaborador();
        void RequestRemove();
        void RequestUpdate();
        void RequestShowColaborador();
        void RequestShowAllColaboradores();
        int RequestMenu();
    }
    #endregion

    #region ClassController
    public class ColaboradorController : IColaboradorController
    {
        #region Atributes
        //Atributos da Classe
        private IColaboradorModel colab; // Define o Modelo de Colaboradores
        private IGuardarColaboradores colabList; // Define a Classe da Lista de Colaboradores
        private IColaboradorView colabView; // Define a View de Colaboradores
        #endregion

        #region Methods

        #region Constructor
        public ColaboradorController()
        {
            colabList = new GuardarColaboradores(); // Define uma nova classe de Guardar Colaboradores
            colabList.LoadColaboradores("colaboradores.bin"); // Carrega a lista do ficheiro
            colabView = new ColaboradorView(this); // Define a view de Colaboradores
        }
        #endregion

        #region Functions
        #region Fluxo de Dados
        public void setModel(IColaboradorModel m) // Define o Model de Colaboradores
        {
            colab = m;
        }
        public void updateColaborador(string n, int c, string m, DateTime d, string cat) // Recebe dados da view para enviar para o model alterar um Cliente
        {
            colab.UpdateColaborador(n, c, m, d, cat);
        }

        public void setModel(IGuardarColaboradores m) // Define o Model da Lista de Clientes
        {
            colabList = m;
        }

        public void NewColaborador(string n, int c, string m, DateTime d, string cat, int nc, DateTime dc, int dcmeses) // Recebe dados da view para enviar para o model adicionar um Colaborador
        {
            Colaborador colaboradorAdicionar = new Colaborador(n, c, m, d, cat, nc, dc, dcmeses);
            if (colabList != null)
            {
                //testar de não existe
                colabList.AddColaborador(colaboradorAdicionar);
            }
        }

        public void SaveColaboradores() // Envia para o Model o path do ficheiro para guardar a lista de colaborador em binário
        {
            colabList.SaveColaboradores("colaboradores.bin");
        }

        public bool SearchColaborador(int id) // Procura na Lista se um determinado ID está presente 
        {
            IColaboradorModel c;
            if (colabList != null)
            {
                //testar de não existe
                c = colabList.FindColaborador(id);
                if (c != null)
                {
                    setModel(c); // Se encontrar instancia esse mesmo model de colaborador (chamar sempre que se quer fazer alterações em um model presente numa lista)
                    return true;
                }
            }
            return false;
        }

        public bool RemoveColaborador(int id) // Recebe um id por parte da View para remover um cliente da Lista
        {

            if (colabList.RemoveColaborador(id))
            {
                return true;
            }
            return false;
        }

        public (string, int, string, DateTime, string, DateTime, int) GiveColaborador(int id) // Envia para a view os dados de um cliente através do seu ID 
        {
            colab = colabList.FindColaborador(id);

            return (colab.Nome, colab.Contacto, colab.Morada, colab.DataNascimento, colab.Categoria, colab.DataContratado, colab.DuracaoContrato);
        }
        #endregion

        #region Views
        public void setView(IColaboradorView v) // Instacia View de Colaborador
        {
            this.colabView = v;
        }
        public void RequestColaborador() // Chama o Método da view que pede para o utilizador adicionar um colaborador
        {
            if (colabView != null)
            {
                colabView.ViewAddColaborador();
            }
        }
        public void RequestRemove() // Chama o Método da View que pede para o utilizador remover um colaborador
        {
            if (colabView != null)
            {
                colabView.ViewRemoveColaborador();
            }
        }

        public void RequestUpdate() // Chama o Método da View que pede para o utilizador atualizar um colaborador
        {
            if (colabView != null)
            {
                colabView.ViewUpdateColaborador();
            }
        }

        public void RequestShowColaborador() // Chama o Método da View que pede um ID ao utilizador para mostrar o colaborador e os seus dados
        {
            if (colabView != null)
            {
                if (colabList != null)
                {
                    colabView.ViewShowColaborador();
                    Console.ReadKey();
                }
                else
                {
                    colabView.ColabNoList();
                }


            }

        }

        public void RequestShowAllColaboradores() // Chama o Método da View que mostra todos os colaborador presentes e os seus dados
        {
            if (colabView != null)
            {
                if (colabList != null)
                {
                    foreach (IColaboradorModel i in colabList.GiveList())
                    {
                        if (i.IsAtivo) // Verifica se o Colaborador foi eliminado para enviar para imprimir
                        {
                            colabView.ViewShowAllColaboradores(i.Nome, i.Contacto, i.Morada, i.DataNascimento, i.Categoria, i.DataContratado, i.DuracaoContrato, i.NColaborador);
                        }
                    }
                    Console.ReadKey();
                }
                else
                {
                    colabView.ColabNoList();
                }
            }

        }
        #endregion

        #region Menu
        public void Menu() //Chama o Método do Menu
        {
            int op = RequestMenu();
            if (op > 0)
            {
                switch (op)
                {
                    case 1:
                        RequestShowAllColaboradores();
                        break;
                    case 2:
                        RequestColaborador();
                        break;
                    case 3:
                        RequestShowColaborador();
                        break;
                    case 4:
                        RequestUpdate();
                        break;
                    case 5:
                        RequestRemove();
                        break;
                    case 6:
                        break;
                }
            }

        }

        public int RequestMenu() //Pede à view que apresente o menu e receba as escolhas do utilizador
        {
            if (colabView != null)
            {
                return colabView.ViewMenuColaborador();
            }
            return -1;
        }
        #endregion
    }
    #endregion

    #endregion
}

#endregion
