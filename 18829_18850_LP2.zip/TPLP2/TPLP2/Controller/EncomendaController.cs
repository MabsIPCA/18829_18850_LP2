﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Model;
using TPLP2.View;

namespace TPLP2.Controller
{
    #region ClassInterface
    public interface IEncomendaController //Interface da classe de encomendas
    {
        void setModel(IEncomendaModel m);
        void setModel(IGuardarEncomendas m);
        void SetColabControl(ref ColaboradorController m);
        void setTransControl(ref TransportadoraController m);
        void setProdControl(ref ProdutoController m);
        void setClienteControl(ref ClienteController m);
        bool ColaboradorExists(int id);
        bool TransportadoraExists(int id);
        bool ClienteExists(int id);
        bool ProdutoExists(int id);
        void Menu(ref ColaboradorController c, ref ClienteController cli,ref TransportadoraController t,ref ProdutoController p);
        void SaveEncomendas();
        (DateTime, int, int, int, bool, bool, DateTime) GiveEncomenda(int id);
        void updateEncomenda(DateTime dataEnc, int transId, int nColab, int cliId);
        void NewEncomenda(int id,int ca, int cl,int trans);
        bool SearchEncomenda(int id);
        bool RemoveEncomenda(int id);
        bool AddProduto(int idProd, int qtd);
        void DeclararEnvio();
        void DeclararEntrega();
        List<string> GiveProdutosEncomenda();
        void setView(IEncomendaView v);
        void RequestEncomenda();
        void RequestRemove();
        void RequestUpdate();
        void RequestUpdateProdutoEncomenda();
        void RequestShowEncomenda();
        void RequestShowAllEncomendas();
        void RequestDeclararEnvio();
        void RequestDeclararEntrega();
        void RequestShowProdutosEncomenda();
        int RequestMenu();
    }
    #endregion

    #region ClassController
    public class EncomendaController:IEncomendaController 
    {
        #region Atributes
        //Atributos da Classe
        private IEncomendaModel enc; // Define o Modelo de Encomendas
        private IGuardarEncomendas encList; // Define a classe da Lista de Encomendas
        private IEncomendaView encView; // Define a View de Encomendas

        private IColaboradorController colabControl; // Define o Controlador de Colaboradores
        private ITransportadoraController transControl; //Define o Controlador de Tranportadoras
        private IProdutoController prodControl; //Define o Controlador de Produtos
        private IClienteController cliControl; //Define o Controlador de Clientes

        #endregion
        #region Methods
        #region Constructor
        public EncomendaController()
        {
            encList = new GuardarEncomendas(); //Define uma nova classe de Guardar Encomendas
            encList.LoadEncomendas("encomendas.bin"); //Carrega a Lista de Encomendas do ficheiro
            encView = new EncomendaView(this); //Define a view de Clientes
        }
        #endregion

        #region Functions
        #region Fluxo de Dados
        public void setModel(IEncomendaModel m) //Define o Model de Encomendas
        {
            enc = m;
        }
        public void updateEncomenda(DateTime dataEnc, int transId, int nColab, int cliId) //Recebe dados da View para enviar para o model alterar uma Encomenda
        {
            enc.UpdateEncomenda( dataEnc,  transId,  nColab,  cliId);
        }

        public void setModel(IGuardarEncomendas m) //Define o Model da Lista de Clientes
        {
            encList = m;
        }

        public void SaveEncomendas() //Envia para a Model o path do ficheiro para guardar a lista de encomendas em binário
        {
            encList.SaveEncomendas("encomendas.bin");
        }
        
        public void setClienteControl(ref ClienteController m) //Define o Controlador de Clientes
        {
            cliControl = m;
        }

        public bool ClienteExists(int id) // Verifica se um determinado Cliente existe
        {
            return cliControl.SearchCliente(id);
        }

        public void SetColabControl(ref ColaboradorController m) // Define o Colaborador de Colaborador
        {
            colabControl = m;
        }
        public bool ColaboradorExists(int id) //Verifica se um determinado Cliente Existe
        {
            return colabControl.SearchColaborador(id);
        }
        public void setTransControl(ref TransportadoraController m) // Define o Controlador de transportadora
        {
            transControl = m;
        }
        public bool TransportadoraExists(int id) // Verifica se uma determinada transportadora exista
        {
            return transControl.SearchTransportadora(id);
        }
        public void setProdControl(ref ProdutoController m) //Define o Controlador de Produto
        {
            prodControl = m;
        }

        public bool ProdutoExists(int id) // Verifica se um determinado produto existe
        {
            return prodControl.SearchProduto(id);
        }
        public bool AddProduto(int idProd, int qtd) // Adiciona um produto ou atualiza a quantidade de um determinado produto em uma encomenda
        {
            enc.UpdateProdEncomenda(idProd, qtd);
            return true;

        }

        public void NewEncomenda(int id,int ca, int cl,int trans) // Envia para o model os dados de uma encomenda para adicionar à lista
        {
            Encomenda encomendaAdicionar = new Encomenda(id,ca, cl,trans);
            if (encList != null)
            {
                //testar de não existe
                encList.AddEncomenda(encomendaAdicionar);
            }
        }

        public bool SearchEncomenda(int id) //Verifica se uma determinada encomenda existe ou nao
        {
            IEncomendaModel e;
            if (encList != null)
            {
                //testar de não existe
                e = encList.FindEncomenda(id);
                if (e != null)
                {
                    setModel(e);
                    return true;
                }
            }
            return false;
        }

        public bool RemoveEncomenda(int id) // Envia para o model o id de uma encomenda para eliminar da lista
        {
            if (encList.RemoveEncomenda(id))
            {
                return true;
            }
            return false;
        }

        public (DateTime, int, int, int, bool, bool, DateTime) GiveEncomenda(int id) //Envia para a view os dados de uma encomenda através do seu ID
        {
            enc = encList.FindEncomenda(id);
            return (enc.DataEncomenda, enc.IdTransportadora, enc.NColaborador, enc.IdCliente, enc.Enviada, enc.Entrege, enc.DataEntrega);
        }

        public void DeclararEnvio() // Faz update do campo de encomenda que diz se foi enviada ou não
        {
            enc.DeclararEnviada();
        }

        public void DeclararEntrega() // Faz update do campo de encomenda que diz se foi entregue ou não
        {
            enc.DeclararEntregue();
        }

        public List<string> GiveProdutosEncomenda() // Envia para a View uma lista de strings com os ID e quantidades de produtos de uma encomenda
        {
            List<string> listProdutosEncomenda = new List<string>();
            string produto;

            foreach(Produto_Encomenda i in enc.Produtos)
            {
                produto = "Id Produto:"+$"<{i.IdProduto}>"+"    ";
                produto += "Quantidade:"+$"<{i.Quantidade}>";
                listProdutosEncomenda.Add(produto);
            }
            return listProdutosEncomenda;
        }
        #endregion

        #region Views
        public void setView(IEncomendaView v) // Define a View de Encomenda
        {
            this.encView = v;
        }

        public void RequestEncomenda() // Chama o Método da View que pede para o utilizador adicionar uma encomenda
        {
            if(encView != null)
            {
                encView.ViewAddEncomenda();
            }
        }
        public void RequestRemove() //Chama o Método da View que pede para o utilizador remover uma encomenda
        {
            if(encView != null)
            {
                encView.ViewRemoveEncomenda();
            }
        }

        public void RequestUpdate() //Chama o Método da View que pede para o utilizador atualizar os dados de uma encomenda
        {
            if(encView != null)
            {
                encView.ViewUpdateEncomenda();
            }
        }

        public void RequestUpdateProdutoEncomenda() //Chama o Método da view que pede para o utilizador atualizar os produtos numa encomenda
        {
            if (encView != null)
            {
                encView.ViewUpdateProdEncomenda();
            }

        }
        public void RequestDeclararEnvio() //Chama o Método da view que pede para o utilizador declarar se a encomenda foi enviada ou não
        {
            if (encView != null)
            {
                encView.ViewUpdateEnvio();
            }
        }
        public void RequestDeclararEntrega() //Chama o Método da view que pede para o utilizador declarar se a encomenda foi entregue ou não
        {
            if (encView != null)
            {
                encView.ViewUpdateEntrega();
            }
        }


        public void RequestShowEncomenda() //Chama o Método da View que mostra os dados referentes a uma encomenda
        {
            if(encView != null)
            {
                if (encList != null)
                {
                    encView.ViewShowEncomenda();

                    Console.ReadKey();
                }
                else
                {
                    encView.EncNoList();
                }
                
            }
            
        }

        public void RequestShowProdutosEncomenda() //Chama o Método da View que mostra os produtos referentes a uma encomenda
        {
            if(encView != null)
            {   
                
                encView.ViewShowProdutosEncomenda();
            }
        }
        

        public void RequestShowAllEncomendas() //Chama o Método da View que mostra os dados de todas as encomendas
        {
            if(encView != null)
            {
                if (encList != null)
                {
                    foreach (IEncomendaModel i in encList.GiveList())
                    {
                        if (i.IsAtivo)
                        {
                            encView.ViewShowAllEncomendas(i.IdEncomenda, i.DataEncomenda, i.IdTransportadora, i.NColaborador, i.IdCliente, i.Enviada, i.Entrege, i.DataEntrega);
                        }
                    }
                    Console.ReadKey();
                }
                else
                {
                    encView.EncNoList();
                }
            }
            
        }
        #endregion

        #region Menu
        public void Menu(ref ColaboradorController c,ref ClienteController cli,ref TransportadoraController t,ref ProdutoController p) //Chama o Método do Menu
        {
            SetColabControl(ref c);
            setClienteControl(ref cli);
            setTransControl(ref t);
            setProdControl(ref p);
            int op = RequestMenu();
            if (op > 0)
            {
                switch (op)
                {
                    case 1:
                        RequestShowAllEncomendas();
                        break;
                    case 2:
                        RequestEncomenda();
                        break;
                    case 3:
                        RequestShowEncomenda();
                        break;
                    case 4:
                        RequestShowProdutosEncomenda();
                        break;
                    case 5:
                        RequestUpdate();
                        break;
                    case 6:
                        RequestUpdateProdutoEncomenda();
                        break;
                    case 7:
                        RequestDeclararEnvio();
                        break;
                    case 8:
                        RequestDeclararEntrega();
                        break;
                    case 9:
                        RequestRemove();
                        break;
                    case 10:
                        break;
                }
            }
        }

        public int RequestMenu() //Pede à view que apresente o menu e receba as escolhas do utilizador
        {
            if (encView != null)
            {
                return encView.ViewMenuEncomenda();
            }
            return -1;
        }
        #endregion
        #endregion

        #endregion
    }
    #endregion
}
