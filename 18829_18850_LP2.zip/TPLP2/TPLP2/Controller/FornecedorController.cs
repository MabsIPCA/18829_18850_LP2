﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Model;
using TPLP2.View;

namespace TPLP2.Controller
{
    #region ClassInterface
    public interface IFornecedorController //Interface do Controller do Fornecedor
    {
        void setModel(IFornecedorModel m);
        void setModel(IGuardarFornecedores m);
        void updateFornecedor(string nome, int con, string mor, string cat);
        void NewFornecedor(int id, string nome, int con, string mor, string cat);
        bool SearchFornecedor(int id);
        bool RemoveFornecedor(int id);
        void Menu();
        void SaveFornecedores();
        void setView(IFornecedorView v);
        (string, int, string, string) GiveFornecedor(int id);
        void RequestRemove();
        void RequestUpdate();
        void RequestShowFornecedor();
        void RequestShowAllFornecedores();
        int RequestMenu();

    }
    #endregion

    #region ClassController
    public class FornecedorController:IFornecedorController
    {
        #region Atributes
        // Atributos da Classe  
        private IFornecedorModel forn; // Define o modelo de fornecedor
        private IGuardarFornecedores fornList; // Define a classe da Lista de Colaborador
        private IFornecedorView fornView; // Define a View de Colaborador
        #endregion

        #region Methods

        #region Constructor
        public FornecedorController()
        {
            fornList = new GuardarFornecedores(); // Define uma nova classe de Guardar Fornecedores
            fornList.LoadFornecedores("fornecedores.bin"); // Carrega a lista do ficheiro
            fornView = new FornecedorView(this); // Define a View de Fornecedores
        }
        #endregion

        #region Functions

        #region Fluxo de Dados
        public void setModel(IFornecedorModel m) //Define o Model de Fornecedores 
        {
            forn = m;
        }
        public void updateFornecedor(string nome, int con, string mor, string cat) // Recebe dados da view para enviar para o model para alterar fornecedor
        {
            forn.UpdateFornecedor( nome,  con,  mor,  cat);
        }

        public void setModel(IGuardarFornecedores m) // Define o Model de Lista de Fornecedores
        {
            fornList = m;
        }

        public void SaveFornecedores() // Envia para o Model o path do ficheiro para guardar a lista de fornecedores em binário
        {
            fornList.SaveFornecedores("fornecedores.bin");
        }


        public void NewFornecedor(int id, string nome, int con, string mor, string cat) // Recebe dados da View para enviar para o model adicionar um Fornecedor
        {
            Fornecedor fornecedorAdicionar = new Fornecedor( nome, con, mor, cat, id);
            if (fornList != null)
            {
                //testar de não existe
                fornList.AddFornecedor(fornecedorAdicionar);
            }
        }

        public bool SearchFornecedor(int id) //Procura na lista se um determinado ID está presente 
        {
            if (fornList != null)
            {
                //testar de não existe
                IFornecedorModel f = fornList.FindFornecedor(id);
                if (f != null)
                {
                    setModel(f); // Se encontrar instancia esse mesmo model de fornecedor (chamar sempre que se quer fazer alterações em um model presente numa lista)
                    return true;
                }
            }
            return false;
        }

        public bool RemoveFornecedor(int id) //Recebe um ID por parte da View para remover um fornecedor na lista
        {
            if (fornList.RemoveFornecedor(id))
            {
                return true;
            }
            return false;
        }

        public (string, int, string, string) GiveFornecedor(int id) //Envia para a view os dados de um fornecedor através do seu ID
        {
            forn = fornList.FindFornecedor(id);

            return (forn.Nome, forn.Contacto, forn.Morada, forn.Categoria);
        }
        #endregion

        #region View
        public void setView(IFornecedorView v) //Instancia View de Fornecedor
        {
            this.fornView = v;
        }

        public void RequestFornecedor() // Chama o Método da view que pede para o utilizador adicionar um fornecedor
        {
            if(fornView != null)
            {
                fornView.ViewAddFornecedor(); 
            }
        }
        public void RequestRemove() // Chama o Método da View que pede para o utilizador remover um fornecedor
        {
            if(fornView != null)
            {
                fornView.ViewRemoveFornecedor();
            }
        }

        public void RequestUpdate() // Chama o Método da View que pede para o utilizador atualizar um fornecedor
        {
            if(fornView != null)
            {
                fornView.ViewUpdateFornecedor();
            }
        }

        public void RequestShowFornecedor() // Chama o Método da View que pede um Id ao utilizador para mostrar o fornecedor e os seus dados
        {
            if(fornView != null)
            {
                if (fornList != null)
                {
                    fornView.ViewShowFornecedor();
                    Console.ReadKey();
                }
                else
                {
                    fornView.FornNoList();
                }
               
            }
            
        }

        public void RequestShowAllFornecedores() // Chama o Método da View que mostra todos os fornecedores presentes na lista e os seus dados 
        {
            if(fornView != null)
            {
                if (fornList != null)
                {
                    foreach (IFornecedorModel i in fornList.GiveList())
                    {
                        if (i.IsAtivo) // Verifica se Cliente foi eliminado para imprimir
                        {
                            fornView.ViewShowAllFornecedores(i.Nome, i.Contacto, i.Morada, i.Categoria, i.IdFornecedor);
                        }
                    }
                    Console.ReadKey();
                }
                else
                {
                    
                }
               
            }
            
            
        }
#endregion

        #region Menu
        public void Menu() //Chama o Método do Menu
        {
            int op = RequestMenu();
            if (op > 0)
            {
                switch (op)
                {
                    case 1:
                        RequestShowAllFornecedores();
                        break;
                    case 2:
                        RequestFornecedor();
                        break;
                    case 3:
                        RequestShowFornecedor();
                        break;
                    case 4:
                        RequestUpdate();
                        break;
                    case 5:
                        RequestRemove();
                        break;
                    case 6:
                        break;
                }
            }

        }

        public int RequestMenu() // Pede à view que apresente o menu e receba as escolhas do utilizador
        {
            if (fornView != null)
            {
                return fornView.ViewMenuFornecedor();
            }
            return -1;
        }
        #endregion

        #endregion
        #endregion
    }
#endregion
}
