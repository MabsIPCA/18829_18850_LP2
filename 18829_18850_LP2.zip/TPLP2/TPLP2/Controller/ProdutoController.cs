﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Model;
using TPLP2.View;

namespace TPLP2.Controller
{

    #region ClassInterface
    public interface IProdutoController //Interface do Controller de Produto
    {
        void setModel(IProdutoModel m);
        void setModel(IGuardarProdutos m);
        void setFornControl(IFornecedorController m);
        void Menu(IFornecedorController f);
        void updateProduto(string nome, string desc, string cat, int fornId, float preco);
        void NewProduto(int id, string nome, string desc, string categ, int idForn, float preco);
        void SaveProdutos();
        bool SearchProduto(int id);
        bool RemoveProduto(int id);
        bool FornecedorExists(int id);
        void setView(IProdutoView v);
        (string, string, string, int, float) GiveProduto(int id);
        void RequestProduto();
        void RequestRemove();
        void RequestUpdate();
        void RequestShowProduto();
        void RequestShowAllProdutos();
    }
    #endregion

    #region ClassController
    class ProdutoController: IProdutoController
    {
        #region Atributes
        // Atributes da Classe
        private IProdutoModel prod; // Define o Modelo de Produto
        private IGuardarProdutos prodList; // Define a classe da Lista de Produtos
        private IProdutoView prodView; // Define a View de Produtos

        private IFornecedorController fornControl; // Define o Controlador de Forecedores
#endregion


        #region Methods

        #region Constructor
        public ProdutoController()
        {
            prodList = new GuardarProdutos(); //Define uma nova classe de guardar Produtos
            prodList.LoadProdutos("produtos.bin"); // Carrega a lista do ficheiro
            prodView = new ProdutoView(this); // Define a View de Produtos
        }
        #endregion

        #region Function
        #region Model
        public void setModel(IProdutoModel m) // Define o Model de Fornecedores
        {
            prod = m;
        }

        public void setFornControl(IFornecedorController m) // Define o Controlador de Fornecedores
        {
            fornControl = m;
        }

        public bool FornecedorExists(int id) // Verifica se o id de fornecedor inserido pelo utilizador existe
        {
            return fornControl.SearchFornecedor(id);
        }

        public void SaveProdutos() // Envia para o Model o path do ficheiro para guardar a lista de produtos em binário
        {
            prodList.SaveProdutos("produtos.bin");
        }
        

        public void updateProduto(string nome, string desc, string cat, int fornId, float preco) // Recebe dados da View para enviar para o model alterar um produto
        {
            prod.UpdateProduto( nome,  desc,  cat,  fornId,  preco);
        }
        
        public void setModel(IGuardarProdutos m) //Define o Model da Lista de produtos
        {
            prodList = m;
        }

        public void NewProduto(int id, string nome, string desc, string categ, int idForn, float preco) //Recebe dados da View para enviar para o model enviar um produtos
        {
            Produto produtoAdicionar = new Produto(id, nome, desc, categ, idForn, preco); ;

            if (prodList != null)
            {
                //testar se não existe
                prodList.AddProduto(produtoAdicionar);
            }
        }

        public bool SearchProduto(int id) //Procura na lista se um determinado ID está presente
        {
            IProdutoModel p;
            if (prodList != null)
            {
                //testar se não existe
                p= prodList.FindProduto(id);
                if (p != null)
                {
                    setModel(p); // Se encontrar instancia esse mesmo model de produto(chamar sempre que se quer fazer alterações em um model presente numa lista)
                    return true;
                }
            }
            return false;
        }

        public bool RemoveProduto(int id) //Recebe um ID por parte da View para remover um cliente da Lista
        {
            if (prodList.RemoveProduto(id))
            {
                return true;
            }
            return false;
        }

        public (string, string, string, int, float) GiveProduto(int id) //Envia para a view os dados de um produto através do seu ID
        {
            prod = prodList.FindProduto(id);

            return (prod.Nome, prod.Descri, prod.Categoria, prod.IdFornecedor, prod.Preco);
        }
#endregion

        #region Views

        public void setView(IProdutoView v) //INstancia View de Produto
        {
            this.prodView = v;
        }
        public void RequestProduto() // Chama o Método da View que pede para o utilizador adicionar um cliente
        {
            if (prodView != null)
            {
                prodView.ViewAddProduto();
            }
        }
        public void RequestRemove() // Chama o Método da View que pede para o utilizador remover um cliente
        {
            if(prodView != null)
            {
                prodView.ViewRemoveProduto();
            }
        }

        public void RequestUpdate() // Chama o Método da View que pede para o utilizador atualizar um cliente
        {
            if(prodView != null)
            {
                prodView.ViewUpdateProduto();
            }
        }
        public void RequestShowProduto() // Chama o Método da View que pede um ID ao utilizador para mostrar o cliente e os seus dados
        {
            if(prodView != null)
            {
                if (prodList != null)
                {
                    prodView.ViewShowProduto();
                    Console.ReadKey();
                }
                else
                {
                    prodView.ProdNoList();
                }
            }
            
            
        }
        public void RequestShowAllProdutos() // Chama o Método da View que mostra todos os clientes presentes e os seu dados
        {
            if(prodView != null)
            {
                if (prodList != null)
                {
                    foreach (IProdutoModel i in prodList.GiveList())
                    {
                        if (i.IsAtivo) //Verifica se o cliente foi eliminado para saber se pode imprimir
                        {
                            prodView.ViewShowAllProdutos(i.Nome, i.Descri, i.Categoria, i.IdFornecedor, i.Preco, i.IdProduto);
                        }
                    }
                    Console.ReadKey();
                }
                else
                {
                    prodView.ProdNoList();
                }
            }
            
            
        }
        #endregion

        #region Menu

        public void Menu(IFornecedorController f) //Chama o Método do Menu
        {
            setFornControl(f);
            int op = RequestMenu();
            if (op > 0)
            {
                switch (op)
                {
                    case 1:
                        RequestShowAllProdutos();
                        break;
                    case 2:
                        RequestProduto();
                        break;
                    case 3:
                        RequestShowProduto();
                        break;
                    case 4:
                        RequestUpdate();
                        break;
                    case 5:
                        RequestRemove();
                        break;
                    case 6:
                        break;
                }
            }
        }

        public int RequestMenu() //Pede à view que apresente o menu e receba as escolhas do utilizador
        {
            if (prodView != null)
            {
                return prodView.ViewMenuProduto();
            }
            return -1;
        }
        #endregion

#endregion
#endregion
    }
#endregion
}
   
