﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Model;
using TPLP2.View;

namespace TPLP2.Controller
{
    #region ClassInterface
    public interface IClienteController //Interface do Controller de Cliente
    {
        void SetModel(IClienteModel m);
        void SetModel(IGuardarClientes m);
        void SetView(IClienteView v);
        void Menu();
        void UpdateCliente(string n, int c, string m, DateTime d, int nif, string empresa);
        void NewCliente(int id, string n, int c, string m, DateTime d, int nif, string empresa);
        bool SearchCliente(int id);
        bool RemoveCliente(int id);
        void SaveClientes();
        (string, string, string, int, int, DateTime) GiveCliente(int id);
        void RequestCliente();
        void RequestRemove();
        void RequestUpdate();
        void RequestShowCliente();
        void RequestShowAllClientes();
        int RequestMenu();
    }
    #endregion

    #region ClassController
    class ClienteController: IClienteController
    {
        #region Atributes
        // Atributos da Classe
        private IClienteModel cli; // Define o modelo de Cliente
        private IGuardarClientes cliList; // Define a classe da Lista de Clientes
        private IClienteView cliView; // Define a View de Cliente
        #endregion

        #region Methods

        #region Constructor
        public ClienteController()
        {
            cliList = new GuardarClientes(); // Define uma nova classe de Guardar Clientes
            cliList.LoadClientes("clientes.bin"); // Carrega a lista do ficheiro
            cliView = new ClienteView(this); // Define a view de Clientes
        }
        #endregion

        #region Functions

        #region Fluxo de Dados
        public void SetModel(IClienteModel m) // Define o Model de Clientes
        {
            cli = m;
        }

        public void UpdateCliente(string n, int c, string m, DateTime d, int nif, string empresa) // Recebe dados da view para enviar para o model alterar um Cliente
        {
            cli.UpdateCliente( n,  c,  m,  d,  nif,  empresa);
        }

        public void SetModel(IGuardarClientes m) // Define o Model da Lista de Clientes
        {
            cliList = m;
        }

        
        public void NewCliente(int id, string n, int c, string m, DateTime d, int nif, string empresa) // Recebe dados da view para enviar para o model adicionar um Cliente
        {
            Cliente clienteAdicionar = new Cliente(n, c , m, d, id , nif, empresa);

            if (cliList != null)
            {
                //testar de não existe
                cliList.AddCliente(clienteAdicionar);
            }
        }

        public void SaveClientes() // Envia para o Model o path do ficheiro para guardar a lista de clientes em binário
        {
            cliList.SaveClientes("clientes.bin");
        }

        public bool SearchCliente(int id) // Procura na Lista se um determinado ID está presente 
        {
            IClienteModel c;
            if (cliList != null)
            {
                //testar de não existe
                c = cliList.FindCliente(id);
                if (c != null)
                {
                    SetModel(c); // Se encontrar instancia esse mesmo model de cliente (chamar sempre que se quer fazer alterações em um model presente numa lista)
                    return true;
                }
            }
            return false;
        }

        public bool RemoveCliente(int id) // Recebe um id por parte da View para remover um cliente da Lista
        {
            if (cliList.RemoveCliente(id))
            {
                return true;
            }
            return false;
        }

        public (string, string, string, int, int, DateTime) GiveCliente(int id) // Envia para a view os dados de um cliente através do seu ID 
        {
            cli = cliList.FindCliente(id);

            return (cli.Nome, cli.Morada, cli.Empresa, cli.Contacto, cli.NIF, cli.DataNascimento);

        }
        #endregion

        #region Views
        public void SetView(IClienteView v) // Instacia View de Cliente
        {
            this.cliView = v;
            
        }

        public void RequestCliente() // Chama o Método da view que pede para o utilizador adicionar um cliente
        {
            if(cliView != null)
            {
                cliView.ViewAddCliente();
            }
        }
        public void RequestRemove() // Chama o Método da View que pede para o utilizador remover um cliente
        {
            if(cliView != null)
            {
                cliView.ViewRemoveCliente();
            }
        }
        public void RequestUpdate() // Chama o Método da View que pede para o utilizador atualizar um cliente
        {
            if(cliView != null)
            {
                cliView.ViewUpdateCliente();
            }
        }
        public void RequestShowCliente() // Chama o Método da View que pede um ID ao utilizador para mostrar o cliente e os seus dados
        {
            if(cliView != null)
            {
                if (cliList != null)
                {
                    cliView.ViewShowCliente();
                    Console.ReadKey();
                }
                else
                {
                    cliView.CliNoList();
                }
                
            }
            
        }
        public void RequestShowAllClientes() // Chama o Método da View que mostra todos os cliente presentes e os seus dados
        {
            if(cliView != null)
            {
                if (cliList != null)
                {
                    foreach (IClienteModel i in cliList.GiveList())
                    {
                        if (i.IsAtivo) // Verifica se o Cliente foi eliminado para enviar para imprimir
                        {
                            cliView.ViewShowAllClientes(i.Nome, i.Empresa, i.Contacto, i.Morada, i.NIF, i.DataNascimento, i.IdCliente);
                        }
                    }
                    Console.ReadKey();
                }
                else
                {
                    cliView.CliNoList();
                }
                
            }
            
        }
        #endregion

        #region Menu
        public void Menu() //Chama o Método do Menu
        {
            int op = RequestMenu();
            if (op > 0)
            {
                switch (op)
                {
                    case 1:
                        RequestShowAllClientes();
                        break;
                    case 2:
                        RequestCliente();
                        break;
                    case 3:
                        RequestShowCliente();
                        break;
                    case 4:
                        RequestUpdate();
                        break;
                    case 5:
                        RequestRemove();
                        break;
                    case 6:
                        break;
                }
            }

        }

        public int RequestMenu() // Pede à view que apresente o menu e receba as escolhas do utilizador
        {
            if (cliView != null)
            {
                return cliView.ViewMenuCliente();
            }
            return -1;
        }
        #endregion

        #endregion
        #endregion

    }
    #endregion
}
