﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2
{
    class Program
    {
        static int Menu()
        {
            int menu_op=0;
            do
            {
                Console.Clear();
                Console.WriteLine("Escolha uma opcao:");
                Console.WriteLine("1) Gerir Clientes");
                Console.WriteLine("2) Gerir Colaboradores");
                Console.WriteLine("3) Gerir Encomendas");
                Console.WriteLine("4) Gerir Fornecedores");
                Console.WriteLine("5) Gerir Produtos");
                Console.WriteLine("6) Gerir Transportadoras");
                Console.WriteLine("7) Sair");
                Console.Write("\r\nOpcao: ");
                try
                {
                    menu_op = int.Parse(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Caracter Invalido");
                    Console.ReadKey();
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Caracter Invalido");
                    Console.ReadKey();
                }
            } while (menu_op > 7 && menu_op < 0);
            return menu_op;
        }
        static void Main(string[] args)
        {

            
            int menu = 0;
            ClienteController cli = new ClienteController();
            ColaboradorController colab = new ColaboradorController();
            EncomendaController enc = new EncomendaController();
            FornecedorController forn = new FornecedorController();
            ProdutoController prod = new ProdutoController();
            TransportadoraController trans = new TransportadoraController();

            do
            {
                menu = Menu();
                switch (menu)
                {
                    case 1:
                        cli.Menu();
                        break;
                    case 2:
                        colab.Menu();
                        break;
                    case 3:
                        enc.Menu(ref colab,ref cli,ref trans, ref prod);
                        break;
                    case 4:
                        forn.Menu();
                        break;
                    case 5:
                        prod.Menu(ref forn);
                        break;
                    case 6:
                        trans.Menu();
                        break;
                    case 7:
                        Console.WriteLine("Obrigado por usar o nosso sistema de gestao de encomendas");
                        break;
                    default:
                        menu = 0;
                        break;
                }
            } while (menu < 7 && menu > 0);
            Console.ReadKey();

            cli.SaveClientes();
            colab.SaveColaboradores();
            enc.SaveEncomendas();
            forn.SaveFornecedores();
            prod.SaveProdutos();
            trans.SaveTransportadoras();
        }
    }
}
