﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2.View
{
    #region ClassInterface
    public interface IColaboradorView
    {
        void ViewAddColaborador();
        void ViewRemoveColaborador();
        void ViewUpdateColaborador();
        void ViewShowColaborador();
        void ViewShowAllColaboradores(string nome, int contacto, string morada, DateTime dataNasc, string categoria, DateTime dataCont, int dura, int id);
        int ViewMenuColaborador();
        void ColabNoList();

    }
    #endregion


    #region ClassView
    public class ColaboradorView : IColaboradorView
    {
        #region Atributes
        private IColaboradorController colabControl;
        #endregion

        #region Methods

        #region Functions
        public ColaboradorView(IColaboradorController cC)
        {
            colabControl = cC;
            colabControl.setView(this);
        }
        public void ViewAddColaborador()
        {
            int nColab;
            int contacto;
            string morada;
            DateTime dataNas;
            string nome;
            string categoria;
            DateTime dataContra;
            int duracaoContra;

            try
            {
                Console.WriteLine("Colaborador a adicionar:");
                Console.WriteLine("Número de Colaborador:");
                nColab = int.Parse(Console.ReadLine());
                Console.WriteLine("Contacto: ");
                contacto = int.Parse(Console.ReadLine());
                Console.WriteLine("Morada: ");
                morada = Console.ReadLine();
                Console.WriteLine("Categoria: ");
                categoria = Console.ReadLine();
                Console.WriteLine("Nome: ");
                nome = Console.ReadLine();
                Console.WriteLine("Data Nascimento: ");
                dataNas = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Data Contratação: ");
                dataContra = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Duração do contrato: ");
                duracaoContra = int.Parse(Console.ReadLine());

                colabControl.NewColaborador(nome,contacto, morada, dataNas, categoria, nColab, dataContra, duracaoContra);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewRemoveColaborador()
        {
            int id;
            try
            {
                Console.WriteLine("Colaborador a eliminar: ");
                id = int.Parse(Console.ReadLine());
                colabControl.RemoveColaborador(id);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewUpdateColaborador()
        {
            string nome;
            int contacto;
            string morada;
            DateTime dataNasc;
            string categoria;
            DateTime dataCont;
            int dura;
            int id;
            bool update;

            try
            {
                Console.WriteLine("ID do Colaborador para alterar: ");
                id = int.Parse(Console.ReadLine());
                update = colabControl.SearchColaborador(id);
                if (update)
                {
                    Console.WriteLine("Nome do Colaborador: ");
                    nome = Console.ReadLine();
                    Console.WriteLine("Contacto: ");
                    contacto = int.Parse(Console.ReadLine());
                    Console.WriteLine("Morada: ");
                    morada = Console.ReadLine();
                    Console.WriteLine("Data de Nascimento: ");
                    dataNasc = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Categoria: ");
                    categoria = Console.ReadLine();
                    Console.WriteLine("Data de Contrato: ");
                    dataCont = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Duracao do contrato: ");
                    dura = int.Parse(Console.ReadLine());

                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewShowColaborador()
        {
            string nome;
            int contacto;
            string morada;
            DateTime dataNasc;
            string categoria;
            DateTime dataCont;
            int dura;
            int id;
            bool show;

            try
            {
                Console.WriteLine("ID do Colaborador para apresentar: ");
                id = int.Parse(Console.ReadLine());
                show = colabControl.SearchColaborador(id);
                if (show)
                {
                    (nome, contacto, morada, dataNasc, categoria, dataCont, dura) = colabControl.GiveColaborador(id);
                    Console.WriteLine("Nome do Colaborador: " + nome);                    
                    Console.WriteLine("Contacto: " + contacto);                    
                    Console.WriteLine("Morada: " + morada);                    
                    Console.WriteLine("Data de Nascimento: " + dataNasc);                   
                    Console.WriteLine("Categoria: " + categoria);                   
                    Console.WriteLine("Data de Contrato: " + dataCont);
                    Console.WriteLine("Duracao do contrato: " + dura);
                    

                }
            }
            catch(FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }

        }
        public void ViewShowAllColaboradores(string nome, int contacto, string morada, DateTime dataNasc, string categoria, DateTime dataCont, int dura, int id)
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("Contacto: " + contacto);
            Console.WriteLine("Morada: " + morada);
            Console.WriteLine("Data de Nascimento: " + dataNasc);
            Console.WriteLine("Categoria: " + categoria);
            Console.WriteLine("Data de Contratado: " + dataCont);
            Console.WriteLine("Duracao do Contrato" + dura);

        }
        public void ColabNoList()
        {
            Console.WriteLine("Não existem colaboradores guardados");
            Console.ReadKey();
        }

        #region Menu
        public int ViewMenuColaborador()
        {
            int menu_op = 0;
            try
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Escolha uma opcao para Colaboradores:");
                    Console.WriteLine("1) Ver Todos");
                    Console.WriteLine("2) Adicionar");
                    Console.WriteLine("3) Ver um");
                    Console.WriteLine("4) Atualizar");
                    Console.WriteLine("5) Eliminar");
                    Console.WriteLine("6) Sair");
                    Console.Write("\r\nOpcao: ");
                    menu_op = int.Parse(Console.ReadLine());
                } while (menu_op > 6 && menu_op < 0);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            return menu_op;
        }
        #endregion

        #endregion

        #endregion
    }

    #endregion

}