﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2.View
{
    #region ClassInterface
    public interface ITransportadoraView
    {
        void ViewAddTransportadora();
        void ViewRemoveTransportadora();
        void ViewUpdateTransportadora();
        void ViewShowTransportadora();
        void ViewShowAllTransportadoras(string nome, int contacto, string morada, int nveiculos, int id);
        int ViewMenuTransportadora();
        void TransNoList();

    }
    #endregion

    #region ClassView
    public class TransportadoraView : ITransportadoraView
    {
        #region Atributes
        private ITransportadoraController transControl;
        #endregion

        #region Methods
        #region Constructor
        public TransportadoraView(ITransportadoraController tC)
        {
            transControl = tC;
            transControl.setView(this);
        }
        #endregion

        #region Functions
        public void ViewAddTransportadora()
        {
            int id;
            int contacto;
            string nome;
            string morada;
            int numVeic;

            try
            {
                Console.WriteLine("Transportadora a adicionar:");
                Console.WriteLine("Id:");
                id = int.Parse(Console.ReadLine());
                Console.WriteLine("Nome: ");
                nome = Console.ReadLine();
                Console.WriteLine("Morada: ");
                morada = Console.ReadLine();
                Console.WriteLine("Contacto: ");
                contacto = int.Parse(Console.ReadLine());
                Console.WriteLine("Número de Veículos: ");
                numVeic = int.Parse(Console.ReadLine());

                transControl.NewTransportadora(id, nome, contacto, morada, numVeic);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewRemoveTransportadora()
        {
            int id;
            try
            {
                Console.WriteLine("Transportadora a eliminar: ");
                id = int.Parse(Console.ReadLine());
                transControl.RemoveTransportadora(id);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewUpdateTransportadora()
        {
            string nome;
            string morada;
            int contacto;
            int nveiculos;
            int id;
            bool update;

            try
            {
                Console.WriteLine("ID da transportadora para alterar: ");
                id = int.Parse(Console.ReadLine());
                update = transControl.SearchTransportadora(id);
                if (update)
                {
                    Console.WriteLine("Nome da Transportadora: ");
                    nome = Console.ReadLine();
                    Console.WriteLine("Contacto: ");
                    contacto = int.Parse(Console.ReadLine());
                    Console.WriteLine("Morada: ");
                    morada = Console.ReadLine();
                    Console.WriteLine("Numero de Veiculos: ");
                    nveiculos = int.Parse(Console.ReadLine());

                    transControl.updateTransportadora(nome, contacto, morada, nveiculos);
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }

        public void ViewShowTransportadora()
        {
            int id;
            bool show;
            string nome;
            string morada;
            int contacto;
            int nveiculos;

            try
            {
                Console.WriteLine("ID da Transportadora a apresentar: ");
                id = int.Parse(Console.ReadLine());
                show = transControl.SearchTransportadora(id);
                if (show)
                {
                    (nome, contacto, morada, nveiculos) = transControl.GiveTransportadora(id);
                    Console.WriteLine("Nome: " + nome);
                    Console.WriteLine("Contacto: " + contacto);
                    Console.WriteLine("Morada: " + morada);
                    Console.WriteLine("Numero de Veiculos: " + nveiculos);
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }

        }
        public void ViewShowAllTransportadoras(string nome, int contacto, string morada, int nveiculos, int id)
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("Contacto: " + contacto);
            Console.WriteLine("Morada: " + morada);
            Console.WriteLine("Numero de Veiculos: " + nveiculos);

        }

        public void TransNoList()
        {
            Console.WriteLine("|Não Existem Transportadoras Guardadas|");
            Console.ReadKey();
        }

        #region Menu
        public int ViewMenuTransportadora()
        {
            int menu_op = 0;
            try
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Escolha uma opcao para Transportadoras:");
                    Console.WriteLine("1) Ver Todos");
                    Console.WriteLine("2) Adicionar");
                    Console.WriteLine("3) Ver um");
                    Console.WriteLine("4) Atualizar");
                    Console.WriteLine("5) Eliminar");
                    Console.WriteLine("6) Sair");
                    Console.Write("\r\nOpcao: ");
                    menu_op = int.Parse(Console.ReadLine());
                } while (menu_op > 6 && menu_op < 0);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            return menu_op;
        }
        #endregion

        #endregion

        #endregion

    }
    #endregion
}
