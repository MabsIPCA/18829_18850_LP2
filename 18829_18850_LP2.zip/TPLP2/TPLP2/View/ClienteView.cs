﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2.View
{
    #region ClasseInterface
    public interface IClienteView
    {
        void ViewAddCliente();
        void ViewRemoveCliente();
        void ViewUpdateCliente();
        void ViewShowCliente();
        void ViewShowAllClientes(string nome, string empresa, int contacto, string morada, int nif, DateTime data, int id);
        int ViewMenuCliente();
        void CliNoList();
    }
    #endregion

    #region ClassView
    public class ClienteView: IClienteView
    {
        #region Atributes
        private IClienteController clientControl; //Define Controlador de Cliente
        #endregion

        #region Methods

        #region Constructor
        public ClienteView(IClienteController cC) //Instancia a view e o controlador
        {
            clientControl = cC;
            clientControl.SetView(this);
        }
        #endregion

        #region Functions

        public void ViewAddCliente()
        {
            DateTime dataNasc;
            int contacto;
            string morada;
            string nome;
            string empresa;
            int nif;
            int id;

            try
            {
                Console.WriteLine("Cliente a Adicionar:");
                Console.WriteLine("ID: ");
                id = int.Parse(Console.ReadLine());
                Console.WriteLine("Data de Nascimento: ");
                dataNasc = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Nome: ");
                nome = Console.ReadLine();
                Console.WriteLine("Morada: ");
                morada = Console.ReadLine();
                Console.WriteLine("Contacto: ");
                contacto = int.Parse(Console.ReadLine());
                Console.WriteLine("Empresa: ");
                empresa = Console.ReadLine();
                Console.WriteLine("NIF: ");
                nif = int.Parse(Console.ReadLine());

                clientControl.NewCliente(id, nome, contacto, morada, dataNasc, nif, empresa);

            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewRemoveCliente()
        {
            int id;
            try
            {
                Console.WriteLine("Cliente a eliminar: ");
                id = int.Parse(Console.ReadLine());
                clientControl.RemoveCliente(id);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }

        public void ViewUpdateCliente()
        {
            string nome;
            int contacto;
            string morada;
            DateTime data;
            int nif;
            string empresa;
            int id;
            bool update;

            try
            {
                Console.WriteLine("ID de Cliente para alterar: ");
                id = int.Parse(Console.ReadLine());
                update = clientControl.SearchCliente(id);
                if (update)
                {
                    Console.WriteLine("Nome do Cliente: ");
                    nome = Console.ReadLine();
                    Console.WriteLine("Contacto do Cliente: ");
                    contacto = int.Parse(Console.ReadLine());
                    Console.WriteLine("Morada do Cliente: ");
                    morada = Console.ReadLine();
                    Console.WriteLine("Data de Nascimento: ");
                    data = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Nif do Cliente: ");
                    nif = int.Parse(Console.ReadLine());
                    Console.WriteLine("Empresa do Cliente: ");
                    empresa = Console.ReadLine();

                    clientControl.UpdateCliente(nome, contacto, morada, data, nif, empresa);

                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }

        public void ViewShowCliente()
        {
            int id;
            bool show;
            string nome;
            string morada;
            string empresa;
            int contacto;
            int nif;
            DateTime data;
            
            try
            {
                Console.WriteLine("Id do cliente a apresentar: ");
                id = int.Parse(Console.ReadLine());
                show = clientControl.SearchCliente(id);
                if (show)
                {
                    (nome, morada, empresa, contacto, nif, data) = clientControl.GiveCliente(id);
                    Console.WriteLine("Nome: " + nome);
                    Console.WriteLine("Empresa: " + empresa);
                    Console.WriteLine("Contacto: " + contacto);
                    Console.WriteLine("Morada: " + morada);
                    Console.WriteLine("NIF: " + nif);
                    Console.WriteLine("Data de Nascimento: " + data);
                }


            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }

        }
        public void ViewShowAllClientes(string nome, string empresa, int contacto, string morada, int nif, DateTime data, int id)
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("Empresa: " + empresa);
            Console.WriteLine("Contacto: " + contacto);
            Console.WriteLine("Morada: " + morada);
            Console.WriteLine("NIF: " + nif);
            Console.WriteLine("Data de Nascimento: " + data);
        }

        public void CliNoList()
        {
            Console.WriteLine("Não há clientes guardados");
            Console.ReadKey();
        }

        #region Menu
        public int ViewMenuCliente()
        {
            int menu_op = 0;
            try
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Escolha uma opcao para Clientes:");
                    Console.WriteLine("1) Ver Todos");
                    Console.WriteLine("2) Adicionar");
                    Console.WriteLine("3) Ver um");
                    Console.WriteLine("4) Atualizar");
                    Console.WriteLine("5) Eliminar");
                    Console.WriteLine("6) Sair");
                    Console.Write("\r\nOpcao: ");
                    menu_op = int.Parse(Console.ReadLine());
                } while (menu_op > 6 && menu_op < 0);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            return menu_op;
        }
        #endregion

        #endregion

        #endregion
    }

    #endregion
}
