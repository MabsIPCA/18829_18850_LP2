﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2.View
{
    #region ClassInterface
    public interface IProdutoView
    {
        void ViewAddProduto();
        void ViewRemoveProduto();
        void ViewUpdateProduto();
        void ViewShowProduto();
        void ViewShowAllProdutos(string nome, string desc, string categoria, int idforn, float preco, int id);
        int ViewMenuProduto();
        void ProdNoList();

    }
    #endregion

    #region ClassView
    public class ProdutoView : IProdutoView
    {
        #region Atributes
        private IProdutoController prodControl;
        #endregion

        #region Methods

        #region Constructor
        public ProdutoView(IProdutoController pC)
        {
            prodControl = pC;
            prodControl.setView(this);
        }
        #endregion

        #region Functions
        public void ViewAddProduto()
        {
            int id;
            string nome;
            string descricao;
            string categoria;
            int idFornecedor;
            float preco;
            try
            {
                Console.WriteLine("Produto a adicionar:");
                Console.WriteLine("Id:");
                id = int.Parse(Console.ReadLine());
                Console.WriteLine("Nome: ");
                nome = Console.ReadLine();
                Console.WriteLine("Descrição: ");
                descricao = Console.ReadLine();
                Console.WriteLine("Categoria: ");
                categoria = Console.ReadLine();
                do
                {
                    Console.WriteLine("Identificação do Fornecedor: ");
                    idFornecedor = int.Parse(Console.ReadLine());
                } while (prodControl.FornecedorExists(idFornecedor) == false);
                
                Console.WriteLine("Preço do produto: ");
                preco = float.Parse(Console.ReadLine());

                prodControl.NewProduto(id, nome, descricao, categoria, idFornecedor, preco);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewRemoveProduto()
        {
            int id;
            try
            {
                Console.WriteLine("Produto a eliminar: ");
                id = int.Parse(Console.ReadLine());
                prodControl.RemoveProduto(id);
            }
            catch(FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch(OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewUpdateProduto()
        {
            string nome;
            string desc;
            string categoria;
            int idForn;
            float preco;
            int id;
            bool update;

            try
            {
                Console.WriteLine("ID do Produto a alterar: ");
                id = int.Parse(Console.ReadLine());
                update = prodControl.SearchProduto(id);
                if (update)
                {
                    Console.WriteLine("Nome do Produto: ");
                    nome = Console.ReadLine();
                    Console.WriteLine("Descricao: ");
                    desc = Console.ReadLine();
                    Console.WriteLine("Categoria: ");
                    categoria = Console.ReadLine();
                    Console.WriteLine("Preco: ");
                    preco = float.Parse(Console.ReadLine());
                    do
                    {
                        Console.WriteLine("Identificação do Fornecedor: ");
                        idForn = int.Parse(Console.ReadLine());
                    } while (prodControl.FornecedorExists(idForn) == false);

                    prodControl.updateProduto(nome, categoria, desc, idForn, preco);
                }
            }
            catch(FormatException){

                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch(OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewShowProduto()
        {
            string nome;
            string desc;
            string categoria;
            int idForn;
            float preco;
            int id;
            bool show;

            try
            {
                Console.WriteLine("ID do Produto a apresentar: ");
                id = int.Parse(Console.ReadLine());
                show = prodControl.SearchProduto(id);
                if (show)
                {

                    (nome, desc, categoria, idForn, preco) = prodControl.GiveProduto(id);
                    Console.WriteLine("Nome do Produto: " + nome);
                    Console.WriteLine("Descricao: " + desc);
                    Console.WriteLine("Categoria: " + categoria);
                    Console.WriteLine("Preco: " + preco);
                    Console.WriteLine("Id do Fornecedor: " + idForn);

                                       
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewShowAllProdutos(string nome, string desc, string categoria, int idForn, float preco, int id)
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Nome do Produto: " + nome);
            Console.WriteLine("Descricao: " + desc);
            Console.WriteLine("Categoria: " + categoria);
            Console.WriteLine("ID do Fornecedor: " + idForn);
            Console.WriteLine("Preco do produto: " + preco);

        }

        public void ProdNoList()
        {
            Console.WriteLine("Não existem produtos guardados");
            Console.ReadKey();
        }

        #region Menu
        public int ViewMenuProduto()
        {
            int menu_op = 0;
            try
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Escolha uma opcao para Produtos:");
                    Console.WriteLine("1) Ver Todos");
                    Console.WriteLine("2) Adicionar");
                    Console.WriteLine("3) Ver um");
                    Console.WriteLine("4) Atualizar");
                    Console.WriteLine("5) Eliminar");
                    Console.WriteLine("6) Sair");
                    Console.Write("\r\nOpcao: ");
                    menu_op = int.Parse(Console.ReadLine());
                } while (menu_op > 6 && menu_op < 0);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            return menu_op;
        }
        #endregion

        #endregion

        #endregion
    }
    #endregion
}