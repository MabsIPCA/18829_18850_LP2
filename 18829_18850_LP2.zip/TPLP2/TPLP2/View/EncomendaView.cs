﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2.View
{
    #region ClassInterface
    public interface IEncomendaView
    {
        void ViewAddEncomenda();
        void ViewRemoveEncomenda();
        void ViewUpdateEncomenda();
        void ViewShowEncomenda();
        void ViewShowAllEncomendas(int idEnc, DateTime dataEnc, int idTrans, int nColab, int idClient, bool env, bool ent, DateTime dataEnt);
        int ViewMenuEncomenda();
        void EncNoList();
        void ViewUpdateProdEncomenda();
        void ViewUpdateEnvio();
        void ViewUpdateEntrega();
        void ViewShowProdutosEncomenda();
    }
    #endregion

    #region ClassView
    public class EncomendaView : IEncomendaView
    {
        #region Atributes
        private IEncomendaController encoControl;
        #endregion

        #region Methods
        #region Constructor
        public EncomendaView(IEncomendaController eC)
        {
            encoControl = eC;
            encoControl.setView(this);
        }
        #endregion

        #region Functions
        public void ViewAddEncomenda()
        {
            int id;
            int idColab;
            int idCliente;
            int idTrans;
            try
            {
                Console.WriteLine("Encomenda a adicionar:");
                Console.WriteLine("Id da encomenda:");
                id = int.Parse(Console.ReadLine());
                

                do
                {
                    Console.WriteLine("ID do Colaborador Responsavel: ");
                    idColab = int.Parse(Console.ReadLine());
                } while (encoControl.ColaboradorExists(idColab)==false);

                do
                {
                    Console.WriteLine("ID do cliente: ");
                    idCliente = int.Parse(Console.ReadLine());
                } while (encoControl.ClienteExists(idCliente)==false);

                do
                {
                    Console.WriteLine("ID da Transportadora: ");
                    idTrans = int.Parse(Console.ReadLine());
                } while (encoControl.TransportadoraExists(idTrans) == false);

                encoControl.NewEncomenda(id,idColab, idCliente, idTrans);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewRemoveEncomenda()
        {
            int id;
            try
            {
                Console.WriteLine("Encomenda a eliminar: ");
                id = int.Parse(Console.ReadLine());
                encoControl.RemoveEncomenda(id);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewUpdateEncomenda()
        {
            DateTime dataEnc;
            int idTrans;
            int nColab;
            int idClient;
            int idEnc;
            bool update;

            

            try
            {
                Console.WriteLine("ID da encomenda a alterar: ");
                idEnc = int.Parse(Console.ReadLine());
                update = encoControl.SearchEncomenda(idEnc);
                if (update)
                {
                    Console.WriteLine("Data da Encomenda: ");
                    dataEnc = DateTime.Parse(Console.ReadLine());
                    do {
                        Console.WriteLine("ID da Transportadora: ");
                        idTrans = int.Parse(Console.ReadLine());
                    } while (encoControl.TransportadoraExists(idTrans)==false);
                    
                    do {
                        Console.WriteLine("ID do Colaborador Responsavel: ");
                        nColab = int.Parse(Console.ReadLine());
                    } while (encoControl.ColaboradorExists(nColab) == false);
                    
                    do {
                        Console.WriteLine("ID do cliente: ");
                        idClient = int.Parse(Console.ReadLine());
                    } while (encoControl.ClienteExists(idClient) == false);
                    

                    encoControl.updateEncomenda(dataEnc, idTrans, nColab, idClient);
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewShowEncomenda() // **fazer show de produtos presentes na encomenda**
        {
            DateTime dataEnc;
            DateTime dataEntr;
            int idTrans;
            int nColab;
            int idClient;
            bool env;
            bool ent;
            int id;
            bool show;

            try
            {
                Console.WriteLine("ID da encomenda a mostrar: ");
                id = int.Parse(Console.ReadLine());
                show = encoControl.SearchEncomenda(id);
                if (show)
                {
                    (dataEnc, idTrans, nColab, idClient, env, ent, dataEntr) = encoControl.GiveEncomenda(id);
                    Console.WriteLine("Data da Encomenda: " + dataEnc);
                    Console.WriteLine("ID da transportadora responsavel: " + idTrans);
                    Console.WriteLine("ID do colaborador Responsavel: " + nColab);
                    Console.WriteLine("ID do cliente: " + idClient);
                    if (env)
                    {
                        Console.WriteLine("Enviada: Sim");
                        if (ent)
                        {
                            Console.WriteLine("Entregue: Sim");
                            Console.WriteLine("Data de Entrega: " + dataEntr);
                        }
                        else
                        {
                            Console.WriteLine("Entregue: Não");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Enviada: Não");
                    }
                   
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewShowAllEncomendas(int idEnc, DateTime dataEnc, int idTrans, int nColab, int idClient, bool env, bool ent, DateTime dataEnt)
        {
            Console.WriteLine("ID da Encomenda: " + idEnc);
            Console.WriteLine("Data da Encomenda: " + dataEnc);
            Console.WriteLine("ID da transportadora responsavel: " + idTrans);
            Console.WriteLine("ID do colaborador Responsavel: " + nColab);
            Console.WriteLine("ID do cliente: " + idClient);
            if (env)
            {
                Console.WriteLine("Enviada: Sim");
                if (ent)
                {
                    Console.WriteLine("Entregue: Sim");
                    Console.WriteLine("Data de Entrega: " + dataEnt);
                }
                else
                {
                    Console.WriteLine("Entregue: Não");
                }
            }
            else
            {
                Console.WriteLine("Enviada: Não");
            }
        }
        public void EncNoList()
        {
            Console.WriteLine("Não existem encomendas guardadas");
            Console.ReadKey();
        }


        public void ViewUpdateProdEncomenda()
        {
            int idEnc = 0, idProd = 0, qtd = 0;
            bool update;
            try
            {
                Console.WriteLine("ID da encomenda a alterar: ");
                idEnc = int.Parse(Console.ReadLine());
                update = encoControl.SearchEncomenda(idEnc);
                if (update)
                {
                    do
                    {
                        Console.WriteLine("ID do produto a adiconar: ");
                        idProd = int.Parse(Console.ReadLine());
                    } while (encoControl.ProdutoExists(idProd) == false);


                    Console.WriteLine("Quantidade do Produto: ");
                    qtd = int.Parse(Console.ReadLine());
                    encoControl.AddProduto(idProd, qtd);
                }

                
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewUpdateEnvio()
        {
            int idEnc;
            bool update;
            try
            {
                Console.WriteLine("ID da encomenda : ");
                idEnc = int.Parse(Console.ReadLine());
                update = encoControl.SearchEncomenda(idEnc);
                if (update)
                {
                    encoControl.DeclararEnvio();
                }                
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewUpdateEntrega()
        {
            int idEnc;
            bool update;
            try
            {
                Console.WriteLine("ID da encomenda : ");
                idEnc = int.Parse(Console.ReadLine());
                update = encoControl.SearchEncomenda(idEnc);
                if (update)
                {
                    encoControl.DeclararEntrega();
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }

        public void ViewShowProdutosEncomenda()
        {
            int id;
            bool show;
            List<string> listProdutos;

            try
            {
                Console.WriteLine("ID da Ecomenda para mostrar os produtos: ");
                id = int.Parse(Console.ReadLine());
                show = encoControl.SearchEncomenda(id);
                if (show)
                {
                    listProdutos = encoControl.GiveProdutosEncomenda();
                    foreach(string i in listProdutos)
                    {
                        Console.WriteLine(i);
                        Console.ReadKey();
                    }
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        #region Menu
        public int ViewMenuEncomenda()
        {
            int menu_op = 0;
            try
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Escolha uma opcao para Encomendas:");
                    Console.WriteLine("1) Ver Todos");
                    Console.WriteLine("2) Adicionar");
                    Console.WriteLine("3) Ver uma");
                    Console.WriteLine("4) Ver Produtos de uma");
                    Console.WriteLine("5) Atualizar");
                    Console.WriteLine("6) Adicionar Produto");
                    Console.WriteLine("7) Declarar Envio");
                    Console.WriteLine("8) Declarar Entrega");
                    Console.WriteLine("9) Eliminar");
                    Console.WriteLine("10) Sair");
                    Console.Write("\r\nOpcao: ");
                    menu_op = int.Parse(Console.ReadLine());
                } while (menu_op > 10 && menu_op < 0);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            return menu_op;
        }
        #endregion
            
        #endregion

        #endregion

    }
    #endregion
}