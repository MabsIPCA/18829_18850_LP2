﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPLP2.Controller;

namespace TPLP2.View
{
    #region ClassInterface
    public interface IFornecedorView
    {
        void ViewAddFornecedor();
        void ViewRemoveFornecedor();
        void ViewUpdateFornecedor();
        void ViewShowFornecedor();
        void ViewShowAllFornecedores(string nome, int contacto, string morada, string categoria, int id);
        int ViewMenuFornecedor();
        void FornNoList();
    }
    #endregion

    #region ClassView
    public class FornecedorView: IFornecedorView
    {
        #region Atributes
        private IFornecedorController fornControl;
        #endregion

        #region Methods

        #region Constructor
        public FornecedorView(IFornecedorController fC)
        {
            fornControl = fC;
            fornControl.setView(this);
        }
        #endregion

        #region Functions
        public void ViewAddFornecedor()
        {
            int id;
            int contacto;
            string morada;
            string nome;
            string categoria;

            try
            {
                Console.WriteLine("Fornecedor a Adicionar:");
                Console.WriteLine("ID: ");
                id = int.Parse(Console.ReadLine());
                Console.WriteLine("Nome: ");
                nome = Console.ReadLine();
                Console.WriteLine("Morada: ");
                morada = Console.ReadLine();
                Console.WriteLine("Contacto: ");
                contacto = int.Parse(Console.ReadLine());
                Console.WriteLine("Categoria: ");
                categoria = Console.ReadLine();

                fornControl.NewFornecedor(id, nome, contacto, morada, categoria);

            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }
        public void ViewRemoveFornecedor()
        {
            int id;
            try
            {
                Console.WriteLine("Fornecedor a eliminar: ");
                id = int.Parse(Console.ReadLine());
                fornControl.RemoveFornecedor(id);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }

        public void ViewUpdateFornecedor()
        {
            string nome;
            string categoria;
            string morada;
            int contacto;
            int id;
            bool update;

            try
            {
                Console.WriteLine("ID do Fornecedor a alterar: ");
                id = int.Parse(Console.ReadLine());
                update = fornControl.SearchFornecedor(id);
                if (update)
                {
                    Console.WriteLine("Nome do Fornecedor: ");
                    nome = Console.ReadLine();
                    Console.WriteLine("Categoria: ");
                    categoria = Console.ReadLine();
                    Console.WriteLine("Morada: ");
                    morada = Console.ReadLine();
                    Console.WriteLine("Contacto: ");
                    contacto = int.Parse(Console.ReadLine());

                    fornControl.updateFornecedor(nome, contacto, morada, categoria);
                    
                }

            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
        }

        public void ViewShowFornecedor()
        {
            int id;
            bool show;
            string nome;
            string morada;
            string categoria;
            int contacto;

            try
            {
                Console.WriteLine("ID do Fornecedor a Apresentar: ");
                id = int.Parse(Console.ReadLine());
                show = fornControl.SearchFornecedor(id);
                if (show)
                {
                    (nome, contacto, morada, categoria) = fornControl.GiveFornecedor(id);
                    Console.WriteLine("Nome: " + nome);
                    Console.WriteLine("Categoria: " + categoria);
                    Console.WriteLine("Morada: " + morada);
                    Console.WriteLine("Contacto: " + contacto);

                }

            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }

        }

        public void ViewShowAllFornecedores(string nome, int contacto, string morada, string categoria, int id)
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("Contacto: " + contacto);
            Console.WriteLine("Morada: " + morada);
            Console.WriteLine("Categoria: " + categoria);
            
        }
        public void FornNoList()
        {
            Console.WriteLine("Não existem fornecedores guardados");
            Console.ReadKey();
        }

        #region Menu
        public int ViewMenuFornecedor()
        {
            int menu_op = 0;
            try
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Escolha uma opcao para Forncedores:");
                    Console.WriteLine("1) Ver Todos");
                    Console.WriteLine("2) Adicionar");
                    Console.WriteLine("3) Ver um");
                    Console.WriteLine("4) Atualizar");
                    Console.WriteLine("5) Eliminar");
                    Console.WriteLine("6) Sair");
                    Console.Write("\r\nOpcao: ");
                    menu_op = int.Parse(Console.ReadLine());
                } while (menu_op > 6 && menu_op < 0);
            }
            catch (FormatException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Caracter Invalido");
                Console.ReadKey();
            }
            return menu_op;
        }
        #endregion

        #endregion

        #endregion
    }
    #endregion
}
